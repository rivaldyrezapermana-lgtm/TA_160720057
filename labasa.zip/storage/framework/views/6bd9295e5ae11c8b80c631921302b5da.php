<?php $__env->startSection('title', 'Pembelian'); ?>
<?php $__env->startSection('breadcrumb'); ?>
    <?php if (isset($component)) { $__componentOriginaldbbc880c47f621cda59b70d6eb356b2f = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldbbc880c47f621cda59b70d6eb356b2f = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.admin.breadcrumb','data' => ['items' => [['label' => 'Pembelian Bahan']]]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin.breadcrumb'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['items' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute([['label' => 'Pembelian Bahan']])]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldbbc880c47f621cda59b70d6eb356b2f)): ?>
<?php $attributes = $__attributesOriginaldbbc880c47f621cda59b70d6eb356b2f; ?>
<?php unset($__attributesOriginaldbbc880c47f621cda59b70d6eb356b2f); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldbbc880c47f621cda59b70d6eb356b2f)): ?>
<?php $component = $__componentOriginaldbbc880c47f621cda59b70d6eb356b2f; ?>
<?php unset($__componentOriginaldbbc880c47f621cda59b70d6eb356b2f); ?>
<?php endif; ?>
    <h1 class="font-display text-xl font-semibold text-ink-900">Pembelian Bahan</h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="bg-white border border-ink-100 rounded-xl overflow-hidden">
    <div class="flex items-center justify-between gap-3 px-5 py-4 border-b border-ink-100">
        <p class="text-sm text-ink-500">PO bahan baku ke supplier.</p>
        <a href="<?php echo e(route('admin.purchases.create')); ?>" class="btn-primary">+ PO Baru</a>
    </div>
    <div class="p-5">
        <table id="tbl-purchases" class="table-clean" style="width:100%">
            <thead><tr><th>Kode</th><th>Supplier</th><th>Tanggal</th><th class="text-right">Total</th><th>Status</th><th class="text-right">Aksi</th></tr></thead>
            <tbody></tbody>
        </table>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
$(function() {
    $('#tbl-purchases').DataTable({
        ajax: '<?php echo e(route("admin.datatables.purchases")); ?>',
        columns: [
            { data: 'code' },
            { data: 'supplier' },
            { data: 'date' },
            { data: 'total', className: 'text-right tabular-nums' },
            { data: 'status', render: d => {
                const map = { pending: 'badge-amber', received: 'badge-green', cancelled: 'badge-red' };
                const label = { pending: 'Pending', received: 'Diterima', cancelled: 'Dibatalkan' };
                return `<span class="${map[d]}">${label[d]}</span>`;
            }},
            { data: 'id', className: 'text-right', render: id => `<a href="/admin/purchases/${id}" class="text-ink-600 hover:text-ink-900 text-sm">Detail</a>` },
        ],
        pageLength: 10, order: [],
        language: { search: 'Cari:', lengthMenu: 'Tampilkan _MENU_', info: 'Menampilkan _START_-_END_ dari _TOTAL_', zeroRecords: '–', paginate: { previous: '‹', next: '›' } }
    });
});
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alber\OneDrive\Documents\Project\ProjectTA\labasa\resources\views/admin/purchases/index.blade.php ENDPATH**/ ?>