<header class="h-16 bg-white border-b border-slate-200 px-6 flex items-center justify-between">
    <div>
        <?php if (! empty(trim($__env->yieldContent('breadcrumb')))): ?>
            <?php echo $__env->yieldContent('breadcrumb'); ?>
        <?php else: ?>
            <h1 class="text-lg font-semibold text-slate-900"><?php echo $__env->yieldContent('title', 'Beranda'); ?></h1>
        <?php endif; ?>
    </div>

    <form action="<?php echo e(route('logout')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <button type="submit" class="btn btn-secondary">
            <svg class="w-4 h-4" fill="none" stroke="currentColor" stroke-width="2" viewBox="0 0 24 24">
                <path stroke-linecap="round" stroke-linejoin="round" d="M17 16l4-4m0 0l-4-4m4 4H7"/>
            </svg>
            Keluar
        </button>
    </form>
</header>
<?php /**PATH C:\Users\alber\OneDrive\Documents\Project\ProjectTA\labasa\resources\views/components/admin/topbar.blade.php ENDPATH**/ ?>