<?php $__env->startSection('title', 'Masuk'); ?>

<?php $__env->startSection('content'); ?>
    <h1 class="text-xl font-semibold text-slate-900 mb-1">Masuk</h1>
    <p class="text-sm text-slate-500 mb-6">Masuk untuk melanjutkan ke akun Anda.</p>

    <?php if($errors->any()): ?>
        <div class="mb-4 bg-red-50 border border-red-200 text-red-700 rounded-lg p-3 text-sm">
            <ul class="list-disc list-inside">
                <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </div>
    <?php endif; ?>

    <form action="<?php echo e(route('login.attempt')); ?>" method="POST">
        <?php echo csrf_field(); ?>

        <div class="field">
            <label class="label" for="email">Email</label>
            <input type="email" name="email" id="email" value="<?php echo e(old('email')); ?>" required autofocus
                placeholder="anda@labasa.id"
                class="input <?php echo e($errors->has('email') ? 'has-error' : ''); ?>">
        </div>

        <div class="field">
            <label class="label" for="password">Kata Sandi</label>
            <input type="password" name="password" id="password" required
                placeholder="••••••••"
                class="input <?php echo e($errors->has('password') ? 'has-error' : ''); ?>">
        </div>

        <label class="flex items-center gap-2 text-sm text-slate-600 mb-6">
            <input type="checkbox" name="remember" class="rounded-md border-slate-300">
            Ingat saya
        </label>

        <button type="submit" class="btn btn-primary">Masuk</button>
    </form>

    <p class="text-sm text-slate-600 text-center mt-6">
        Belum punya akun?
        <a href="<?php echo e(route('register')); ?>" class="text-emerald-700 hover:text-emerald-800 font-medium">Daftar</a>
    </p>

    <div class="mt-6 pt-4 border-t border-slate-200 text-xs text-slate-500">
        <p class="font-medium text-slate-700 mb-1">Akun Demo</p>
        <p>admin@labasa.test · karyawan@labasa.test · pembeli@labasa.test</p>
        <p>Kata sandi: <code class="bg-slate-100 px-1 py-0.5 rounded">password</code></p>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alber\OneDrive\Documents\Project\ProjectTA\labasa\resources\views/auth/login.blade.php ENDPATH**/ ?>