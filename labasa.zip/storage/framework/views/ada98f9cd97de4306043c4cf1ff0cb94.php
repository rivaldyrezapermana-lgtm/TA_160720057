<?php $__env->startSection('title', $product->name); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-6 py-10">
    <nav class="text-sm text-ink-500 mb-6">
        <a href="<?php echo e(route('home')); ?>" class="hover:text-ink-900">Beranda</a> ·
        <a href="<?php echo e(route('shop.index')); ?>" class="hover:text-ink-900">Belanja</a> ·
        <span class="text-ink-900"><?php echo e($product->name); ?></span>
    </nav>

    <div class="grid grid-cols-1 md:grid-cols-2 gap-12">
        
        <div class="relative aspect-[4/5] bg-ink-100 rounded-2xl overflow-hidden">
            <?php if($product->image): ?>
                <img src="<?php echo e(asset('storage/' . $product->image)); ?>" alt="<?php echo e($product->name); ?>" class="w-full h-full object-cover">
            <?php else: ?>
                <div class="w-full h-full flex items-center justify-center">
                    <span class="font-display text-6xl text-ink-300"><?php echo e(substr($product->category->name, 0, 1)); ?></span>
                </div>
            <?php endif; ?>
            <?php if($product->stock <= 0): ?>
                <div class="absolute inset-0 bg-ink-900/55 flex items-center justify-center">
                    <span class="text-white text-sm font-semibold uppercase tracking-[0.2em] border border-white/70 rounded-full px-4 py-1.5">Stok Habis</span>
                </div>
            <?php endif; ?>
        </div>

        
        <div>
            <p class="text-xs uppercase tracking-[0.18em] text-ink-500 font-semibold"><?php echo e($product->category->name); ?></p>
            <h1 class="font-display text-4xl font-semibold mt-2"><?php echo e($product->name); ?></h1>
            <p class="font-display text-3xl font-semibold mt-4">Rp <?php echo e(number_format($product->price, 0, ',', '.')); ?></p>

            <div class="h-px bg-ink-100 my-6"></div>

            <p class="text-ink-700 leading-relaxed"><?php echo e($product->description); ?></p>

            <form action="<?php echo e(route('cart.add')); ?>" method="POST" class="mt-8 space-y-4">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="product_id" value="<?php echo e($product->id); ?>">

                <?php if($product->sizes->isNotEmpty()): ?>
                    <div>
                        <label class="label">Pilih Ukuran</label>
                        <div class="grid grid-cols-4 gap-2">
                            <?php $__currentLoopData = $product->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <label class="cursor-pointer">
                                    <input type="radio" name="size" value="<?php echo e($s->size); ?>" class="peer sr-only" <?php echo e($loop->first ? 'checked' : ''); ?> <?php echo e($s->stock <= 0 ? 'disabled' : ''); ?>>
                                    <div class="border border-ink-200 rounded-lg py-3 text-center peer-checked:border-ink-900 peer-checked:bg-ink-900 peer-checked:text-white peer-disabled:opacity-40 peer-disabled:cursor-not-allowed transition">
                                        <p class="font-medium"><?php echo e($s->size); ?></p>
                                        <p class="text-[10px] opacity-70"><?php echo e($s->stock); ?> pcs</p>
                                    </div>
                                </label>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>

                <div>
                    <label class="label">Jumlah</label>
                    <input type="number" name="qty" value="1" min="1" max="<?php echo e(max($product->stock, 1)); ?>" class="input w-32">
                </div>

                <div class="flex gap-3 pt-2">
                    <?php if($product->stock <= 0): ?>
                        <button type="button" disabled class="btn-secondary flex-1 justify-center opacity-60 cursor-not-allowed">Stok Habis</button>
                    <?php else: ?>
                        <?php if(auth()->guard()->check()): ?>
                            <button class="btn-primary flex-1 justify-center">Tambah ke Keranjang</button>
                            <?php if(auth()->user()->isPembeli()): ?>
                                <a href="<?php echo e(route('customer.chat.index')); ?>" class="btn-secondary">Tanya Penjual</a>
                            <?php endif; ?>
                        <?php else: ?>
                            <a href="<?php echo e(route('login')); ?>" class="btn-primary flex-1 justify-center">Masuk untuk Membeli</a>
                        <?php endif; ?>
                    <?php endif; ?>
                </div>
            </form>

            
            <?php if($product->sizes->isNotEmpty()): ?>
                <details class="mt-8 border-t border-ink-100 pt-6">
                    <summary class="cursor-pointer font-medium text-ink-900 list-none flex items-center justify-between">
                        Tabel Ukuran (cm)
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path stroke-linecap="round" stroke-linejoin="round" stroke-width="1.5" d="M19 9l-7 7-7-7"/></svg>
                    </summary>
                    <table class="w-full mt-4 text-sm">
                        <thead><tr class="border-b border-ink-100"><th class="text-left py-2 text-xs uppercase tracking-wider text-ink-500 font-semibold">Size</th><th class="text-right py-2 text-xs uppercase tracking-wider text-ink-500 font-semibold">Lingkar Dada</th><th class="text-right py-2 text-xs uppercase tracking-wider text-ink-500 font-semibold">Panjang</th><th class="text-right py-2 text-xs uppercase tracking-wider text-ink-500 font-semibold">Lengan</th></tr></thead>
                        <tbody>
                            <?php $__currentLoopData = $product->sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr class="border-b border-ink-50 last:border-0">
                                    <td class="py-2 font-medium"><?php echo e($s->size); ?></td>
                                    <td class="py-2 text-right tabular-nums"><?php echo e($s->chest_cm); ?></td>
                                    <td class="py-2 text-right tabular-nums"><?php echo e($s->length_cm); ?></td>
                                    <td class="py-2 text-right tabular-nums"><?php echo e($s->sleeve_cm); ?></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </details>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alber\OneDrive\Documents\Project\ProjectTA\labasa\resources\views/customer/shop/show.blade.php ENDPATH**/ ?>