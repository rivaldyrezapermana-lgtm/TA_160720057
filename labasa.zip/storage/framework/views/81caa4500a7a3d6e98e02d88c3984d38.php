<?php $__env->startSection('title', 'Belanja'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto px-6 py-10">
    <div class="mb-8">
        <h1 class="font-display text-4xl font-semibold">Belanja</h1>
        <p class="text-ink-600 mt-2">Semua produk Toko Labasa.</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-4 gap-8">
        
        <aside class="md:col-span-1">
            <form method="GET" class="space-y-6 sticky top-24">
                <div>
                    <label class="label">Cari</label>
                    <input type="text" name="q" value="<?php echo e(request('q')); ?>" placeholder="Nama produk..." class="input">
                </div>
                <div>
                    <p class="text-xs uppercase tracking-wider text-ink-500 font-semibold mb-3">Kategori</p>
                    <div class="space-y-2">
                        <label class="flex items-center gap-2 text-sm">
                            <input type="radio" name="category" value="" <?php echo e(!request('category') ? 'checked' : ''); ?> class="border-ink-300">
                            Semua
                        </label>
                        <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <label class="flex items-center gap-2 text-sm">
                                <input type="radio" name="category" value="<?php echo e($c); ?>" <?php echo e(request('category') === $c ? 'checked' : ''); ?> class="border-ink-300">
                                <?php echo e($c); ?>

                            </label>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
                <button class="btn-primary w-full">Terapkan</button>
            </form>
        </aside>

        
        <div class="md:col-span-3">
            <?php if($products->isEmpty()): ?>
                <div class="border border-dashed border-ink-200 rounded-xl p-16 text-center">
                    <p class="font-display text-xl text-ink-700">Tidak ada produk ditemukan</p>
                    <p class="text-sm text-ink-500 mt-1">Coba ubah kata kunci atau kategori.</p>
                </div>
            <?php else: ?>
                <p class="text-sm text-ink-500 mb-4"><?php echo e($products->count()); ?> produk</p>
                <div class="grid grid-cols-2 lg:grid-cols-3 gap-6">
                    <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <a href="<?php echo e(route('shop.show', $p->id)); ?>" class="group">
                            <div class="relative aspect-[4/5] bg-ink-100 rounded-xl overflow-hidden mb-3">
                                <?php if($p->image): ?>
                                    <img src="<?php echo e(asset('storage/' . $p->image)); ?>" alt="<?php echo e($p->name); ?>" class="w-full h-full object-cover">
                                <?php else: ?>
                                    <div class="w-full h-full flex items-center justify-center">
                                        <span class="font-display text-3xl text-ink-300"><?php echo e(substr($p->category->name, 0, 1)); ?></span>
                                    </div>
                                <?php endif; ?>
                                <?php if($p->stock <= 0): ?>
                                    <div class="absolute inset-0 bg-ink-900/55 flex items-center justify-center">
                                        <span class="text-white text-xs font-semibold uppercase tracking-[0.18em] border border-white/70 rounded-full px-3 py-1">Stok Habis</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            <p class="text-xs uppercase tracking-wider text-ink-500"><?php echo e($p->category->name); ?></p>
                            <p class="font-medium text-ink-900 mt-1 group-hover:underline underline-offset-2"><?php echo e($p->name); ?></p>
                            <div class="flex items-center justify-between mt-1">
                                <p class="font-display text-lg font-semibold">Rp <?php echo e(number_format($p->price, 0, ',', '.')); ?></p>
                                <?php if($p->stock > 0 && $p->stock < 10): ?>
                                    <span class="badge-amber">Stok terbatas</span>
                                <?php endif; ?>
                            </div>
                        </a>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alber\OneDrive\Documents\Project\ProjectTA\labasa\resources\views/customer/shop/index.blade.php ENDPATH**/ ?>