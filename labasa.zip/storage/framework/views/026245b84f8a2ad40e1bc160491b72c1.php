<?php $__env->startSection('title', $order->code); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-5xl mx-auto px-6 py-10">
    <nav class="text-sm text-ink-500 mb-6">
        <a href="<?php echo e(route('customer.orders.index')); ?>" class="hover:text-ink-900">Pesanan Saya</a> · <span class="text-ink-900"><?php echo e($order->code); ?></span>
    </nav>

    <div class="flex items-start justify-between mb-8">
        <div>
            <h1 class="font-display text-3xl font-semibold"><?php echo e($order->code); ?></h1>
            <p class="text-sm text-ink-500 mt-1">Dipesan pada <?php echo e($order->created_at->translatedFormat('d M Y, H:i')); ?></p>
        </div>
        <?php if (isset($component)) { $__componentOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-badge','data' => ['status' => $order->status]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($order->status)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8)): ?>
<?php $attributes = $__attributesOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8; ?>
<?php unset($__attributesOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8)): ?>
<?php $component = $__componentOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8; ?>
<?php unset($__componentOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8); ?>
<?php endif; ?>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
        
        <div class="md:col-span-2 space-y-6">
            <div class="bg-white border border-ink-100 rounded-xl p-6">
                <h2 class="font-display text-xl font-semibold mb-4">Status Pesanan</h2>
                <div class="relative pl-8">
                    <div class="absolute left-3 top-2 bottom-2 w-px bg-ink-200"></div>
                    <?php $__currentLoopData = $timeline; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="relative pb-5 last:pb-0">
                            <div class="absolute -left-8 w-6 h-6 rounded-full <?php echo e($t['done'] ? 'bg-ink-900 text-white' : 'bg-white border-2 border-ink-200 text-ink-400'); ?> flex items-center justify-center text-xs font-semibold">
                                <?php if($t['done']): ?> ✓ <?php else: ?> <?php echo e($i+1); ?> <?php endif; ?>
                            </div>
                            <p class="font-medium <?php echo e($t['done'] ? 'text-ink-900' : 'text-ink-400'); ?>"><?php echo e($t['label']); ?></p>
                            <p class="text-xs <?php echo e($t['done'] ? 'text-ink-500' : 'text-ink-400'); ?>"><?php echo e($t['time']); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
            </div>

            <div class="bg-white border border-ink-100 rounded-xl p-6">
                <h2 class="font-display text-xl font-semibold mb-4">Item</h2>
                <div class="space-y-3">
                    <?php $__currentLoopData = $order->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="flex gap-4 items-center">
                            <div class="w-16 h-16 bg-ink-100 rounded-lg flex-shrink-0 overflow-hidden">
                                <?php if($i->product?->image): ?>
                                    <img src="<?php echo e(asset('storage/'.$i->product->image)); ?>" class="w-full h-full object-cover" alt="">
                                <?php endif; ?>
                            </div>
                            <div class="flex-1 min-w-0">
                                <p class="font-medium text-ink-900"><?php echo e($i->product?->name ?? '—'); ?></p>
                                <p class="text-xs text-ink-500"><?php echo e($i->qty); ?>× · Size <?php echo e($i->size ?? '-'); ?></p>
                            </div>
                            <p class="font-display text-lg font-semibold tabular-nums">Rp <?php echo e(number_format($i->subtotal, 0, ',', '.')); ?></p>
                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </div>
                <div class="border-t border-ink-100 mt-4 pt-4 flex justify-between items-baseline">
                    <span class="font-medium">Total</span>
                    <span class="font-display text-2xl font-semibold tabular-nums">Rp <?php echo e(number_format($order->total, 0, ',', '.')); ?></span>
                </div>
            </div>
        </div>

        
        <div class="space-y-6">
            <div class="bg-white border border-ink-100 rounded-xl p-5">
                <h3 class="font-medium mb-2">Pengiriman</h3>
                <p class="text-sm text-ink-600 whitespace-pre-line"><?php echo e($order->shipping_address); ?></p>
            </div>

            <div class="bg-white border border-ink-100 rounded-xl p-5">
                <h3 class="font-medium mb-2">Pembayaran</h3>
                <?php $payment = $order->payment; $pStatus = $payment?->status ?? 'pending'; ?>
                <div class="text-sm space-y-1">
                    <p class="text-ink-500">Metode: <span class="text-ink-900 capitalize"><?php echo e($payment?->method ?? '-'); ?></span></p>
                    <p class="text-ink-500">Status: <?php if (isset($component)) { $__componentOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.ui.status-badge','data' => ['status' => $pStatus]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('ui.status-badge'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['status' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($pStatus)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8)): ?>
<?php $attributes = $__attributesOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8; ?>
<?php unset($__attributesOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8); ?>
<?php endif; ?>
<?php if (isset($__componentOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8)): ?>
<?php $component = $__componentOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8; ?>
<?php unset($__componentOriginaldf5a194c1ccdd1698e9a89f0cb5bf2c8); ?>
<?php endif; ?></p>
                </div>

                <?php if($payment?->proof_image): ?>
                    <a href="<?php echo e(asset('storage/'.$payment->proof_image)); ?>" target="_blank" class="text-xs text-ink-900 underline mt-2 inline-block">Lihat bukti transfer</a>
                <?php endif; ?>

                <?php if($pStatus === 'rejected'): ?>
                    <div class="mt-3 rounded-lg bg-red-50 border border-red-200 p-3">
                        <p class="text-xs font-semibold text-red-700">Bukti pembayaran ditolak</p>
                        <?php if($payment->note): ?>
                            <p class="text-xs text-red-600 mt-1">Alasan: <?php echo e($payment->note); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endif; ?>

                <?php if($pStatus === 'verified'): ?>
                    <p class="text-xs text-emerald-600 mt-2">Pembayaran sudah diverifikasi.</p>
                <?php elseif($pStatus === 'pending' && $payment?->proof_image): ?>
                    <p class="text-xs text-amber-600 mt-2">Menunggu verifikasi admin.</p>
                <?php else: ?>
                    
                    <form action="<?php echo e(route('checkout.proof', $order->id)); ?>" method="POST" enctype="multipart/form-data" class="mt-3 space-y-2">
                        <?php echo csrf_field(); ?>
                        <input type="file" name="proof" accept="image/*" required class="input text-xs">
                        <button class="btn-primary w-full justify-center text-sm"><?php echo e($pStatus === 'rejected' ? 'Upload Ulang Bukti' : 'Upload Bukti'); ?></button>
                    </form>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.customer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\alber\OneDrive\Documents\Project\ProjectTA\labasa\resources\views/customer/orders/show.blade.php ENDPATH**/ ?>