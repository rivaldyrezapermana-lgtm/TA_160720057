<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['tone' => 'gray']));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['tone' => 'gray']), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars); ?>
<?php
    $map = [
        'gray'  => 'bg-slate-100 text-slate-700',
        'green' => 'bg-emerald-50 text-emerald-700',
        'amber' => 'bg-amber-50 text-amber-700',
        'red'   => 'bg-red-50 text-red-700',
        'blue'  => 'bg-blue-50 text-blue-700',
        'dark'  => 'bg-slate-900 text-white',
    ];
?>
<span <?php echo e($attributes->merge(['class' => 'inline-flex items-center px-2 py-0.5 rounded-lg text-xs font-medium '.($map[$tone] ?? $map['gray'])])); ?>>
    <?php echo e($slot); ?>

</span>
<?php /**PATH C:\Users\alber\OneDrive\Documents\Project\ProjectTA\labasa\resources\views/components/ui/badge.blade.php ENDPATH**/ ?>