# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## Project context

"Labasa" is a Laravel 11 application for a small Islamic-clothing business: an e-commerce storefront (Gamis, Koko, Tunik, Hijab) plus an internal admin/production system. It is an academic project (Tugas Akhir / TA) — the Fuzzy Mamdani production-quantity recommendation in `app/Services/FuzzyMamdaniService.php` is the core algorithmic contribution and is referenced by the proposal (Bab II: Djunaidi et al. 2005, Simajuntak & Fauzi 2017).

User-facing strings are in **Indonesian** (`Bahasa Indonesia`). Match the existing language when adding flash messages, validation errors, button labels, etc.

## Common commands

PowerShell is the default shell on this machine. `&&` and `||` are not available in Windows PowerShell 5.1 — chain with `;` or `if ($?) { ... }`.

```powershell
# Install
composer install

# Run everything (server + queue + pail logs) in one terminal
composer dev

# Or run pieces individually
php artisan serve
php artisan queue:listen --tries=1
php artisan pail --timeout=0

# Database
php artisan migrate
php artisan migrate:fresh --seed   # nuke + reseed (uses DatabaseSeeder)
php artisan db:seed

# Tests
php artisan test                                  # all
php artisan test --testsuite=Unit                 # one suite
php artisan test --filter=FuzzyMamdaniTest        # one test class/method
vendor/bin/phpunit tests/Unit/SomeTest.php        # single file via phpunit

# Lint / format
vendor/bin/pint
```

The default DB is **MySQL** (`DB_DATABASE=labasa` per `.env`), but `database/database.sqlite` also exists for the `post-create-project-cmd` flow. `phpunit.xml` has SQLite-in-memory env lines commented out — uncomment them if you need to run feature tests without a MySQL server.

## Architecture

### Routing layout (`routes/web.php`)

Three audience tiers, separated by middleware groups:

1. **Public / storefront** — `/`, `/shop`, `/shop/product/{product}` → `Customer\ShopController`. No auth.
2. **Customer area** — `auth` + `role:pembeli`. Cart, checkout, my-orders, customer chat.
3. **Admin area** — `auth` + `role:admin,karyawan`, prefix `/admin`, name `admin.`. Master data (categories, products, materials, suppliers, users), operations (purchases, productions), recommendations, orders, chat, reports.

The `role` middleware is **custom**, aliased in `bootstrap/app.php` (Laravel 11 has no `app/Http/Kernel.php`). It accepts comma-separated roles: `->middleware('role:admin,karyawan')`. Source: `app/Http/Middleware/RoleMiddleware.php`. Roles are constants on `User`: `ROLE_ADMIN`, `ROLE_KARYAWAN`, `ROLE_PEMBELI`, with `isAdmin() / isKaryawan() / isPembeli()` helpers. Login redirects branch on `isPembeli()` (→ `home`) vs. else (→ `admin.dashboard`).

### Fuzzy Mamdani service

`App\Services\FuzzyMamdaniService::calculate(demand, stock, history)` is the production-quantity recommender. Pipeline:

1. **Fuzzification** — linear ascending/descending memberships for `demand` (NAIK/TURUN) and `stock` (BANYAK/SEDIKIT) over min/max derived from `$history`.
2. **Inference** — 4 rules combined with MIN (AND), aggregated with MAX over each consequent (BERKURANG / BERTAMBAH).
3. **Defuzzification** — weighted-average over consequent crisp z values (`zBerkurang = pMin + 0.25·range`, `zBertambah = pMin + 0.85·range`). Returns a structured array with all intermediate values for the UI to display step-by-step.

`Admin\RecommendationController` consumes it. Note: the controller currently uses **hardcoded sample history** in `create()` and `calculate()` (matches the proposal's worked example) — the `// TODO: load real history for this product` is the integration point with `SalesHistory` when wiring real data.

### Stub controllers — important

Many admin controllers (e.g. `Admin\ProductController`) return **hardcoded fake data via `(object)[…]` casts and `collect(range(...))->map(…)`**, not Eloquent queries. Look for `// TODO: replace with server-side query` comments. When asked to "implement X", check whether the controller is currently a stub before assuming the data flow; the models and migrations exist but most read paths aren't connected yet. The exceptions are auth and the seeder, which use the real models.

### Admin DataTables pattern

Admin index pages use **client-side jQuery DataTables** (loaded via CDN in `layouts/admin.blade.php`) that fetch JSON from dedicated AJAX endpoints under `/admin/datatables/{resource}`. These endpoints live as `data()` methods on the same resource controller (e.g. `ProductController@data`). When adding a new admin list, register both the resource route and a `datatables.{resource}` route.

### Frontend / styling

- **Tailwind is loaded via CDN** in `resources/views/layouts/admin.blade.php` (`<script src="https://cdn.tailwindcss.com">`) — the CDN config defines the `ink` and `accent` color palettes inline. There is **no Vite/npm build pipeline**: it was removed, so no `@vite(...)` directives, `package.json`, or `node_modules` exist. All styling comes from the CDN. If you ever need a real build pipeline for production, re-add Laravel's default Vite scaffolding.
- Component conventions: `<x-admin.sidebar />`, `<x-admin.topbar />`, `<x-admin.data-table>`, `<x-admin.stat-card>`, plus generic `<x-ui.*>` (badge, card, input, modal, select). Three Blade layouts: `layouts.admin`, `layouts.customer`, `layouts.auth`.
- Fonts: Fraunces (display) + Inter Tight (body). Two custom Tailwind palettes: `ink-{50..900}` (warm neutral) and `accent-{50,500,600,700}` (sage green).
- Admin AJAX uses jQuery with a global CSRF setup at the bottom of `layouts/admin.blade.php`. Reuse that pattern instead of fetch/axios in admin views.

### Models & relationships

Domain split:
- **Catalog**: `Category`, `Product`, `ProductSize` (per-size chest/length/sleeve/stock), `ProductMaterial` (the product's bill of materials — `qty_required` per unit; `Product hasMany ProductMaterial`, `Material hasMany ProductMaterial`).
- **Inventory / production**: `Material`, `Supplier`, `Purchase` + `PurchaseItem`, `Production` + `ProductionStage`, `ProductionMachine` (`Production belongsTo ProductionMachine` via nullable `production_machine_id`; `ProductionMachine::STATUSES = ['active','maintenance','inactive']`). `Production::STATUSES = ['planned','in_progress','qc','completed','cancelled']`. Note: materials are NOT tied to a production batch — they live on the product as a recipe, and creating a production no longer decrements material stock.
- **Sales**: `Order` + `OrderItem` + `Payment`, `SalesHistory` (per product/year/month — feeds Fuzzy Mamdani).
- **Comms**: `ChatThread` + `ChatMessage` (polled, not broadcast — see `chat/poll` routes).

### Seed accounts

`DatabaseSeeder` creates three logins, all with password `password`:
- `admin@labasa.test` — admin
- `karyawan@labasa.test` — karyawan
- `pembeli@labasa.test` — pembeli

Plus 4 categories, 4 products with S/M/L/XL sizes and a `ProductMaterial` bill of materials each, 8 materials, 3 `ProductionMachine` rows, 3 suppliers, and 12 months of `SalesHistory` rows for product_id=1 (the worked example from the proposal).
